
# Bank Robot Workspace (ROS2)

Este monorepo contiene 4 paquetes:

- **bank_robot_nlp**: clasificador de intenciones **incremental** (scikit‑learn `partial_fit`) con un mapa de intenciones → destinos.
- **bank_robot_routes**: aprendizaje **incremental** de rutas (ajuste de destinos y correcciones on‑line) + puente a **Nav2**.
- **bank_robot_pathlearn**: *preentrenamiento* con el dataset de Kaggle **2D Path Planning** + actualización incremental auto‑supervisada en ejecución.
- **bank_robot_bringup**: lanzamiento unificado.

> Referencias útiles para los flujos y datos:
> - Incremental/online con scikit‑learn (notebook Kaggle): https://www.kaggle.com/code/unofficialmerve/incremental-online-training-with-scikit-learn
> - KITTI‑odometry (notebook Kaggle): https://www.kaggle.com/code/ruithemid/kitti-odometry
> - 2D Path Planning dataset (Kaggle): https://www.kaggle.com/datasets/dcaffo/2dpathplanningdataset
> - Demo CNN (GitHub) para ese dataset: https://github.com/dcaffo98/path-planning-cnn
> - Documentación de Nav2: https://docs.nav2.org/

## Requisitos
- ROS2 Humble/Foxy.
- Nav2 instalado y operativo (mapa y `navigate_to_pose`).
- Python 3.8+ con `scikit-learn`, `numpy`, `torch`, `torchvision`, `opendatasets` para el preentrenamiento.

## Build
```bash
cd bank_robot_ws
colcon build --symlink-install
source install/setup.bash
```

## Lanzamiento (supón Nav2 funcionando en paralelo)
```bash
ros2 launch bank_robot_bringup robot_service.launch.py
# Simula entrada de voz como texto
ros2 topic pub /user_text std_msgs/String "data: 'quiero hacer un deposito'"
```

## Preentrenamiento (opcional)
Ejecuta `bank_robot_pathlearn/path_cnn_pretrain.py` para descargar el dataset 2D de Kaggle y entrenar una CNN de coste de celdas. Copia los pesos en `weights/path_prior.pt` y habilita el nodo `path_cnn_runtime_node` en el launch.

## Notas
- Ajusta las coordenadas de destino en `intents.yaml` a tu `world`.
- El aprendizaje incremental de rutas usa un **replay** ligero y heurísticas de “frente ocupado” para desplazar destinos cuando se detectan zonas conflictivas repetidas.

